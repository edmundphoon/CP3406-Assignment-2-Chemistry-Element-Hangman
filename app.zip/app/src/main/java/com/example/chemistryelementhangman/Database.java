package com.example.chemistryelementhangman;

public class Database {

    static Integer[] elements = {
            R.drawable.aluminium_symbol,
            R.drawable.carbon_symbol,
            R.drawable.chlorine_symbol,
            R.drawable.copper_symbol,
            R.drawable.fluorine_symbol,
            R.drawable.helium_symbol,
            R.drawable.hydrogen_symbol,
            R.drawable.iron_symbol,
            R.drawable.lithium_symbol,
            R.drawable.magnesium_symbol,
            R.drawable.neon_symbol,
            R.drawable.nitrogen_symbol,
            R.drawable.oxygen_symbol,
            R.drawable.phosphorus_symbol,
            R.drawable.potassium_symbol,
            R.drawable.silicon_symbol,
            R.drawable.sodium_symbol,
            R.drawable.sulfur_symbol,
            R.drawable.zinc_symbol,
    };

    final String[] answers = {
            "aluminium",
            "carbon",
            "chlorine",
            "copper",
            "fluorine",
            "helium",
            "hydrogen",
            "iron",
            "lithium",
            "magnesium",
            "neon",
            "nitrogen",
            "oxygen",
            "phosphorus",
            "potassium",
            "silicon",
            "sodium",
            "sulfur",
            "zinc"
    };
}
